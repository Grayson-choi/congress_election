from django.apps import AppConfig


class KakaoConfig(AppConfig):
    name = 'kakao'
